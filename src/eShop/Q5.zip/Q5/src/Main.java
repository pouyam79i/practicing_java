/**
 * <h1>Main Class</h1>
 * <p>
 *     This is the Main class of my online shop programm.<br>
 *     To test this app you must run method main.
 * </p>
 *
 * @author Pouya Mohammadi - CE@AUT Uni ID: 9829039
 * @version 1.0
 * @since 2021 April 21th
 */

import java.util.Locale;
import java.util.Scanner;

/**
 * Class Main
 */
public class Main {

    /**
     * Method main, this must be run to test the application
     * @param args inputs
     */
    public static void main(String[] args) {
        Menu menu = new Menu();
        Scanner scanner = new Scanner(System.in);
        Inventory inventory = new Inventory();
        inventory.refreshProducts();
        String input = "";

        while (true){
            System.out.println(menu.mainMenu);
            input = scanner.nextLine();
            if(input.equals("1")){
                System.out.println(menu.shoppingMenu[0]);
                String customerID = scanner.nextLine();
                System.out.println(inventory);
                System.out.println(menu.shoppingMenu[1]);
                Basket newBasket = new Basket();
                while (true){
                    input = scanner.nextLine();
                    String[] inputArray = input.split(" ");
                    if(inputArray[0].toLowerCase(Locale.ROOT).equals("add")){
                        int index = Integer.parseInt(inputArray[1]);
                        Product currentProduct = inventory.getProduct(index);
                        if(currentProduct == null){
                            System.out.println("Wrong index");
                            continue;
                        }
                        if(inventory.reduce(index)){
                            newBasket.add(currentProduct);
                            System.out.println("One of this item added");
                        }else {
                            System.out.println("Out of stoke!");
                        }
                    }
                    else if(inputArray[0].toLowerCase(Locale.ROOT).equals("remove")){
                        int index = Integer.parseInt(inputArray[1]);
                        Product selectedProduct = newBasket.getProduct(index);
                        if(selectedProduct == null){
                            System.out.println("Wrong index");
                            continue;
                        }
                        int numberOfItems = newBasket.getNumberOfItem(selectedProduct);
                        inventory.refreshItemInStoke(selectedProduct, numberOfItems);
                        newBasket.remove(selectedProduct);
                    }
                    else if(input.toLowerCase(Locale.ROOT).equals("cart")){
                        if(newBasket.toString().equals("null")) {
                            System.out.println("Basket is empty");
                            continue;
                        }
                        System.out.println(newBasket);
                    }
                    else if(input.toLowerCase(Locale.ROOT).equals("products")){
                        System.out.println(inventory);
                    }
                    else if(input.toLowerCase(Locale.ROOT).equals("checkout")){
                        ReceiptPackager receiptPackager = new ReceiptPackager(customerID, newBasket.toString());
                        if(newBasket.toString().equals("null")){
                            System.out.println("Basket was empty!\n");
                            System.out.println("Thanks for waisting time :/\n");
                            break;
                        }
                        System.out.println(newBasket);
                        receiptPackager.buildReceipt();
                        System.out.println("It was a pleasure doing business with you.\n");
                        break;
                    }
                    else if(input.toLowerCase(Locale.ROOT).equals("leave")){
                        System.out.println("Thanks for waisting time :/\n");
                        break;
                    }
                }
            }
            else if(input.equals("2")){
                System.out.println("\nSorry but I did not have enough time to complete this part :////");
                System.out.println("To add or remove a product go to the 'ProductStorage/products.json' and edit the file");
                System.out.println("Pay attention to the structure of file :) do not ruin it\n");
            }
            else if(input.equals("3")){
                break;
            }
        }
    }

}

