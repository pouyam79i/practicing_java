/**
 * <h1>Basket Class</h1>
 * <p>
 *     This class is used when sb is buying products from the shop
 * </p>
 *
 * @author Pouya Mohammadi - CE@AUT Uni ID: 9829039
 * @version 1.0
 * @since 2021 April 21th
 */

import java.util.ArrayList;
import java.util.HashMap;


/**
 * Basket Class
 */
public class Basket {

    /**
     * Contains List of Items and Number of them
     */
    private HashMap<Product, Integer> basket;
    /**
     * Contains Products to maintain keys and order
     */
    private ArrayList<Product> keys;

    /**
     * Constructor of Basket class
     */
    public Basket(){
        basket = new HashMap<Product, Integer>();
        keys = new ArrayList<Product>();
    }

    /**
     * Adds a new product or add one more item to an existing product
     * @param product will be added
     */
    public void add(Product product){
        if(keys.contains(product)){
            int currentNumberOfProduct = basket.get(product);
            currentNumberOfProduct++;
            basket.put(product, currentNumberOfProduct);
        }else {
            basket.put(product, 1);
            keys.add(product);
        }
    }

    /**
     * Returns a product in the basket
     * @param index of product
     * @return Product if fount, else null
     */
    public Product getProduct(int index){
        if(index < keys.size() && index >= 0){
            return keys.get(index);
        }
        return null;
    }

    public int getNumberOfItem(Product product){
        if(keys.contains(product)){
            return basket.get(product);
        }else {
            return 0;
        }
    }

    /**
     * Remove an existing product.
     * @param product will be removed!
     */
    public void remove(Product product){
        basket.remove(product);
        keys.remove(product);
    }

    /**
     * makes the a list of all existing item in basket!
     * @return the list of items in basket.
     */
    @Override
    public String toString(){
        int index;
        StringBuilder output = new StringBuilder();
        for (index = 0; index < keys.size(); index++){
            Product product = keys.get(index);
            int inStoke = basket.get(product);
            output.append(index).append("){\n").append(product).append("\n}inBasket:").append(inStoke).append("\n");
        }
        if(index == 0)
            return "null";
        return output.toString();
    }

}

