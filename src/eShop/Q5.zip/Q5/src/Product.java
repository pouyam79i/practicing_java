/**
 * <h1>Product Class</h1>
 * <p>
 *     This class contains the information of products.
 * </p>
 *
 * @author Pouya Mohammadi - CE@AUT Uni ID: 9829039
 * @version 1.0
 * @since 2021 April 21th
 */

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Product Class
 */
public class Product {

    private String name;
    private String category;
    private double price;
    private double weight;
    private Date manufactureDate;
    private Date expirationDate;

    /**
     * Gets the basic information of product
     * @param name of product
     * @param category of product
     * @param weight of product
     * @param price of product
     * @param manufactureDate of product
     * @param expirationDate of product
     */
    public Product(String name, String category,
                   double weight, double price,
                   Date manufactureDate,
                   Date expirationDate){
        this.name = name;
        this.category = category;
        this.price =  Math.abs(price);
        this.weight = Math.abs(weight);
        this.manufactureDate = manufactureDate;
        this.expirationDate = expirationDate;
    }


    /**
     * @return the Product Info
     */
    @Override
    public String toString(){
        DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy", Locale.ENGLISH);
        return  "   Product: {\n" +
                "        \"NAME\": \"" + name + "\"\n" +
                "        \"CATEGORY\": \"" + category + "\"\n" +
                "        \"WEIGHT\": \"" + weight + "\"\n" +
                "        \"PRICE\": \"" + price + "\"\n" +
                "        \"MANUFACTURE_DATE\": \"" + dateFormat.format(manufactureDate) + "\"\n" +
                "        \"EXPIRATION_DATE\": \"" + dateFormat.format(expirationDate) + "\"\n" +
                "   }";
    }

}

