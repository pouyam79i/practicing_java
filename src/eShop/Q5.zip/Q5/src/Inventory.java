/**
 * <h1>Inventory Class</h1>
 * <p>
 *     This class organize the products of the shop.
 * </p>
 *
 * @author Pouya Mohammadi - CE@AUT Uni ID: 9829039
 * @version 1.0
 * @since 2021 April 21th
 */

import java.io.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

/**
 * Inventory Class
 */
public class Inventory {

    /**
     * List of Items and Number of these Items
     */
    private HashMap<Product, Integer> products;
    /**
     * Keys of Products
     */
    private ArrayList<Product> keys;

    /**
     * Constructor of Inventory
     */
    public Inventory(){
        products = new HashMap<Product, Integer>();
        keys = new ArrayList<Product>();
    }

    /**
     * Reduce the number of in-stoke
     * @param index of that item
     * @return true if it could reduce, else false
     */
    public boolean reduce(int index){
        Product currentProduct = keys.get(index);
        int inStoke = products.get(currentProduct);
        if(inStoke <= 0)
            return false;
        inStoke--;
        products.put(currentProduct, inStoke);
        return true;
    }

    /**
     * refresh the number of in-stoke of a product
     * @param product which is the key
     * @param increment the amount to be added!
     */
    public void refreshItemInStoke(Product product, int increment){
        int inStoke = products.get(product);
        inStoke += increment;
        products.put(product, inStoke);
    }

    /**
     * Returns a product in the basket
     * @param index of product
     * @return Product if fount, else null
     */
    public Product getProduct(int index){
        if(index < keys.size() && index >= 0){
            return keys.get(index);
        }
        return null;
    }

    /**
     * Run and check the readStorageFile() method!
     * Prints a reasonable message!
     */
    public void refreshProducts(){
        if(readStorageFile())
            System.out.println("Refreshing products completed!");
        else {
            System.out.println("Something went wrong while refreshing :(");
        }
    }

    /**
     * @return the list of products in json format
     */
    @Override
    public String toString(){
        int index;
        StringBuilder output = new StringBuilder();
        for (index = 0; index < keys.size(); index++){
            Product product = keys.get(index);
            int inStoke = products.get(product);
            if(inStoke == 0)
                continue;
            output.append(index).append("){\n").append(product).append("\n}inStoke:").append(inStoke).append("\n");
        }
        return output.toString();
    }

    /**
     * It fomrats the date which is given as a string
     * Then puts it to the Date class
     * @param inputDate which is a string
     * @return Date class object which has the same date as input
     */
    private Date stringToDate(String inputDate){
        try {
            Date date;
            DateFormat format = new SimpleDateFormat("dd-MM-yyyy", Locale.ENGLISH);
            date = format.parse(inputDate);
            new Debug(date.toString());
            return date;
        }catch (Exception err){
            new Debug("Something went wrong while converting string to Date");
            return null;
        }
    }

    /**
     * This is method read a json file called products.json
     * In this json file we have the all products in the storage of our initial program!
     * This json file changes, if we buy something. (After finishing the shopping)
     * @return true if it could read the json file, else false.
     */
    private boolean readStorageFile(){
        JSONParser parser = new JSONParser();
        try{
            Object object = parser.parse(new FileReader("ProductStorage/products.json"));
            new Debug("Opened the json file");
            JSONArray jsonArray = (JSONArray) object;
            for (Object productObject : jsonArray) {
                JSONObject jsonObject = (JSONObject) productObject;
                Date manufactureDate = stringToDate((String) jsonObject.get("manufactureDate"));
                Date expirationDate = stringToDate((String) jsonObject.get("expirationDate"));
                if(manufactureDate.after(expirationDate))           // It does not let this happens
                    continue;
                Product newProduct = new Product((String) jsonObject.get("productName"),
                        (String) jsonObject.get("category"),
                        Double.parseDouble((String) jsonObject.get("weight")),
                        Double.parseDouble((String) jsonObject.get("price")),
                        expirationDate, manufactureDate
                );
                int itemInStoke = Integer.parseInt((String) jsonObject.get("inStoke"));
                new Debug(newProduct.toString());
                add(newProduct, itemInStoke);
            }
            return true;
        }catch(Exception err){
            System.out.println("Error while reading json file");
            err.printStackTrace();
            return false;
        }
    }

    /**
     * Adds a new product to the inventory
     * @param newProduct will be added
     * @param inStoke is the number of available new products
     */
    private void add(Product newProduct, int inStoke){
        products.put(newProduct, inStoke);
        keys.add(newProduct);
    }

}

