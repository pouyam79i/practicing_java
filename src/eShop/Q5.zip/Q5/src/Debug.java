/**
 * <h1>Debug Class</h1>
 * <p>
 *     This class prints debug flags
 * </p>
 *
 * @author Pouya Mohammadi - CE@AUT Uni ID: 9829039
 * @version 1.0
 * @since 2021 April 21th
 */

/**
 * Debug Class
 */
public class Debug {

    /**
     * Debug Mode
     * if true, prints all debug stuff you have written in the code
     * else, nothing happens
     */
    private boolean debugMode = false;

    /**
     * @param input will be printed
     */
    public Debug(String input){
        if (debugMode)
            System.out.println("### Debug data: " + input);
    }

    /**
     * @param flagNumber will be printed
     */
    public Debug(int flagNumber){
        if(debugMode)
            System.out.println("### Flag Number: " + flagNumber);
    }

    /**
     * @param flagNumber will be printed
     * @param address of flag number, will be printed
     */
    public Debug(int flagNumber, String address){
        if (debugMode)
            System.out.println("### Flag Number: " + flagNumber + " - Address: " + address);
    }

}
