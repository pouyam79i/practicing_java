/**
 * <h1>Menu Class</h1>
 * <p>
 *     This class contains the information of menu.
 * </p>
 *
 * @author Pouya Mohammadi - CE@AUT Uni ID: 9829039
 * @version 1.0
 * @since 2021 April 21th
 */

public class Menu {

    public final String mainMenu = """
            1 - Start Shopping
            2 - System Admin
            3 - Exit
            """;

    public final String[] shoppingMenu = {
            """
            Enter Your ID:

""",
            """
            to add one item enter: add k 
            to remove a product from basket enter: remove k
            to show the basket items enter: cart
            to show the remaining items in the inventory enter: products
            to finish shopping enter: checkout
            to leave enter: leave
             
"""
    };

    public final String[] adminMenu = {
            """
            1 - Add product
            2 - Remove product
            3 - Back
""",
            """
            to add a new product enter the product information like what is shown below:
            Name#Category#Weight#Price#'ManufactureDate'dd-mm-yyyy#'ExpirationDate'dd-mm-yyyy#InStoke
                    - remember that '#' must not be used for anything else!
                    - if you want to exit just enter: #DONE
                    - example:
                    Milk#Dairy#100#20#10-1-2020#25-1-2020#20
                    
""",
            """
            Only prints the index of product you want to delete
             - if you want to exit just enter: #DONE
"""
    };

}

