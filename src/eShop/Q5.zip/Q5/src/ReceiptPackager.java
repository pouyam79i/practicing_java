/**
 * <h1>ReceiptPackager Class</h1>
 * <p>
 *     This class make receipt for the customer!
 * </p>
 *
 * @author Pouya Mohammadi - CE@AUT Uni ID: 9829039
 * @version 1.0
 * @since 2021 April 21th
 */

import java.io.File;
import java.io.FileWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class ReceiptPackager {

    /**
     * Last reciept ID
     */
    private String receiptID;
    /**
     * Customer ID
     */
    private String customerID;
    /**
     * List of products
     */
    private String basketContent;

    /**
     * Gets the Basket and Costumets ID to build the basket
     * @param customerID is the ID of person who is shopping.
     * @param basketContent is list of product Item.
     */
    public ReceiptPackager(String customerID, String basketContent){
        this.customerID = customerID;
        this.basketContent = basketContent;
    }

    /**
     * Updates the Baskket Items
     * @param basketContent will be set as new list.
     */
    public void updateBasket(String basketContent){
        this.basketContent = basketContent;
    }

    /**
     * This method make the output receipt file which is a json file.
     * @return true if it could create the json file, else false.
     */
    public boolean buildReceipt(){
            try {
                Date date = new Date();
                DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy-hh-mm-ss", Locale.ENGLISH);
                receiptID = customerID + dateFormat.format(date);
                File file = new File("./Receipts/" + receiptID + ".txt");
                FileWriter fileWriter = new FileWriter(file);
                fileWriter.write(basketContent);
                fileWriter.flush();
                fileWriter.close();
                return true;
            }catch (Exception err2){
                new Debug("Something went wrong while writing receipt file !");
                return false;
            }
    }

}

